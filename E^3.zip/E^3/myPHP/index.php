<?
include("dbinfo.inc.php");
mysql_connect(localhost,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query="SELECT * FROM dcmsData";
$result=mysql_query($query);

//$num=24; 
$num=mysql_numrows($result);
mysql_close();

echo "<b><center>Data Center Monitoring System</center></b><br><br>";

?>
<table border="0" cellspacing="2" cellpadding="2">
<tr> 
<th><font face="Arial, Helvetica, sans-serif">Humidity</font></th>
<th><font face="Arial, Helvetica, sans-serif">Light</font></th>
<th><font face="Arial, Helvetica, sans-serif">Noise</font></th>
<th><font face="Arial, Helvetica, sans-serif">Smoke</font></th>
<th><font face="Arial, Helvetica, sans-serif">Temperature</font></th>
<th><font face="Arial, Helvetica, sans-serif">AC</font></th>
<th><font face="Arial, Helvetica, sans-serif">DayTime</font></th>

</tr>

<?
$i = 0;
$count = $num-24;
//while ($i < $num) {
while ($num > $count) {
$i=$num;
$Humidity=mysql_result($result,$i,"Humidity");
$Light=mysql_result($result,$i,"Light");
$Noise=mysql_result($result,$i,"Noise");
$Smoke=mysql_result($result,$i,"Smoke");
$Temperature=mysql_result($result,$i,"Temperature");
$AC=mysql_result($result,$i,"AC");
$DayTime=mysql_result($result,$i,"DayTime"); 
?>

<tr> 
<td><font face="Arial, Helvetica, sans-serif"><? echo "$Humidity";?></font></td><td><font face="Arial ,Helvetica, sans-serif"><? echo "$Light";  ?></font></td>
<td><font face="Arial, Helvetica, sans-serif"><? echo "$Noise";  ?></font></td>
<td><font face="Arial, Helvetica, sans-serif"><? echo "$Smoke";  ?></font></td>
<td><font face="Arial, Helvetica, sans-serif"><? echo "$Temperature"; ?></font></td>
<td><font face="Arial, Helvetica, sans-serif"><? echo "$AC"; ?></font></td>
<td><font face="Arial, Helvetica, sans-serif"><? echo "    $DayTime"; ?></font></td>
</tr>
<?
//++$i;
$num=$num-1;
} 
echo "</table>";


?>
