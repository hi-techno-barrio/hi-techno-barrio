<?
$username="root";
$password="yourPassword";
$database="yourDataBase";
?> 
