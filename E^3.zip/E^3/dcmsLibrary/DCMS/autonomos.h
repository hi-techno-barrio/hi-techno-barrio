


void ACdata()
{
}

// Autonomos robot
// The line following robot
void independentrobot()
{
  
}

//Guided robot
void dependentrobot()
{
  
}


void robotCommand( char *serialdata)
{
  
    if (serialdata="dependent")
      {
      dependentrobot();
      }
    if (serialdata="independent") 
     {
      independentrobot();
      }  
}


int  cameraPosition()
{
 int camPos=0;
return camPos;
}
























