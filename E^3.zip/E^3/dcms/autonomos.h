// Purpose
//  The floatToAscii function converts a floating point
//  value and outputs a formatted char array/string.
//
// Input parameters
//  value:     value to be converted to ascii
//  buffer:    char array/string buffer for transformation (size of 10min)
//  polarized: indicates if output is singed (±) or unsigned
//
// Return
//  ±nnn.nn (polarized) or nnn.nn (non-polarized)
char* floatToAscii(float value, char *buffer, boolean polarized)
{
  byte pos = 0;
  char *ret = buffer;
  //
  // fixed output length:
  // 7 (polarized) or 6 (unpolarized) chars neeeded

  // compute rounding-up factor
  // note: -existing examples don't round
  //       negative number correctly
  //       -0.001 prevents .349999 which
  //       would yield .34 when casted
  if ( value > 0 ) {
    value += 0.001;
    value += 0.5/(float)100;
  } else {
    value -= 0.001;
    value -= 0.5/(float)100;
  }
  
  // validate input value range
  if ( value < -999.99 || value > 999.99 ) value = 999.999;
  
  // polarized format includes ±
  // while unpolarized is unsigned
  if ( polarized ) {
    //
    if ( value > 0 ) {
      ret[pos++] = '+';
    } else {
      ret[pos++] = '-';
    }
  }
  
  // set value positive
  if (value < 0 ) value = -value;
  
  // pad whole number with leading 0s
  if ( value < 10 ) {
    ret[pos++] = '0';
    ret[pos++] = '0';
  } else if ( value > 10 && value < 100 ) {
    ret[pos++] = '0';
  }
  
  // convert formated whole number
  itoa((short)value, ret+pos, 10);
  
  // append decimal place
  strcat(ret,".");
  
  //put the frac after the decimal
  itoa((value - (short)value) * 100, &ret[strlen(ret)], 10);
  
  // validate output length
  if ( polarized) {
    if ( strlen(ret) < 7 ) {
      // missing padding after decimal
      ret[6] = '0';
      ret[7] = '\0';
    } else if ( strlen(ret) > 7 ) {
      // shave off 0s
      ret[7] = '\0'; // terminate
    }
  } else {
    if ( strlen(ret) < 6 ) {
      // missing padding after decimal
      ret[5] = '0';
      ret[6] = '\0';
    } else if ( strlen(ret) > 6 ) {
      // shave off 0s
      ret[6] = '\0'; // termniate
    }
  }

  return ret;
}


int distanceGap(int sensor)
{
  int distanceValue,measureData;
  switch (sensor)
 {
   case '1':
   distanceValue,measureData;
   break;
   case '2':
   distanceValue,measureData;
   break;
   case '3':
   distanceValue,measureData;
   break;
   case '4':
   distanceValue,measureData;
   break;
   
    
 } 
}

void ACData()
{
}

// Autonomos robot
// The line following robot
void independentrobot()
{
  
}

//Guided robot
void dependentrobot()
{
  
}


void robotCommand( char *serialdata)
{
  
    if (serialdata="dependent")
      {
      dependentrobot();
      }
    if (serialdata="independent") 
     {
      independentrobot();
      }  
}

int  cameraPosition()
{
 int camPos=0;
return camPos;
}

