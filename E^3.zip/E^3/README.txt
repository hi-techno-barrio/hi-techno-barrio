// Christopher M Coballes
// Hi-Techno Barrio


(1) dcms - is the main folder for dcms.ino, you can choose functions you preferred in the program ;ex: DHT,LM35 ,URF and etc.

(2) dcmsLibrary-This is the file where you will add to your  arduino library.You may read the files to acknowledge the programmer behind it.

(3) myPHP -is a sample code for PHP

(4) mySQL.txt - is a document on how you can build your schema and some hints in your mySQL












