

This Document includes the following files:

[Quick References:]
1) Shibboleth Quick Installations-Windows
2) Shibboleth Quick Installations-Linux
3) Identity Provider Metadata-Structure
4) Service Provider Metadata-Structure
5) Quick Installations-Federations
6) Shibboleth Deployment Guide

[Example Document]
1) IdP-etc
2) SP-etc

Note***

This document is still subjected to
editions, though prior notice will
be given to the designated recipients


CopyRight 2008-2009
Christopher M. Coballes,ITO-1
Data Center Main Library,UP Diliman