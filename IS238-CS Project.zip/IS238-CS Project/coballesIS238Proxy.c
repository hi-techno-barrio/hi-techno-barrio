
/******************************************************************************************************************* 

   Christopher M Coballes                                                                               20XX-8818X 
   MIS Student                                                                                    September 6,2012
   IS238 (Client & Server Programming)
   
   History Notes:(related work)
   Wcol proxy server
*********************************************************************************************************************/
/*Please read "README file to see further details or instructions about the program(s-code) */


/* basic header C header files */
#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* system header files */

#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <sys/resource.h>
#include <sys/wait.h>

/* network status header files */
#include <netinet/in.h>
#include <signal.h>
#include <netdb.h>
#include <errno.h>

#define NONE (fd_set *) NULL
#define NEVER (struct timeval *) NULL
#define IGNORE (struct sockaddr *) NULL

#define PORTTEST 8000

int display = 0;
char buffer[4096];
int httpport;
int sessionSocket;
fd_set active;
struct sockaddr_in sc_in;
FILE *lfp = NULL;
char **info;


/**************************************************************************************************/
/* void statusHTTPServer( int HTTPerror, char *errorMsg) */ 
/**************************************************************************************************/
void statusHTTPServer( int HTTPerror, char *errorMsg)
{
switch (HTTPerror)
{

  case HOST_NOT_FOUND:
   sprintf(errorMsg,"Sorry, this host could not be identified by the DNS server.\nCheck for the correct address");
	break;
   case TRY_AGAIN:
	sprintf(errorMsg,"Sorry, there is a temporary problem with the DNS server .Please try again.");
	break;
   case NO_DATA:
        sprintf(errorMsg,"Sorry, this is a virtual host without an IP address.");
	break;
   default:
       sprintf(errorMsg,"Unable to resolve this host name to an IP address.");
}
} /* statusHTTP */


/**************************************************************************************************/
/* void statusHTTPConnections( int HOSTerror, char *errorMsg) */ 
/**************************************************************************************************/
void statusHTTPConnections( int HOSTerror, char *errorMsg)
{
switch(HOSTerror) 
{

  case ECONNREFUSED:
       sprintf(errorMsg,"Sorry, this host is refusing connections from this machine on the specified port.\n");
       break;
  case EHOSTUNREACH:
  case ENETUNREACH:
       sprintf(errorMsg,"Sorry, this host is currently unreachable from this network.\n");
       break;
  case EHOSTDOWN:
  case ENETDOWN:
       sprintf(errorMsg,"Sorry, this host is down.  Try again later.\n");
       break;
  case ETIMEDOUT:
       sprintf(errorMsg,"Sorry, the connection to this host was timed out. \n");
       break;
      default:
  sprintf(errorMsg,"Sorry, this host is not responding.  The remote host being down, or incorrect port number in the wwwHOST.");
}
} /* statusHTTPHost */


/**************************************************************************************************/
/* void proxyMSG(int fd,char *title, char *head, char *body) */ 
/**************************************************************************************************/
void proxyMSG(int fd,char *title, char *head, char *body)
{
	sprintf(buffer,"<HEAD><TITLE>HTTP Proxy Server Message</TITLE></HEAD>\n<BODY>\n");
	write(fd,buffer,strlen(buffer));
	if(title) {
		sprintf(buffer,"<H1>%s</H1>\n",title);
		write(fd,buffer,strlen(buffer));
            
	}
	if(head) {
		sprintf(buffer,"<H2>%s</H2>\n",head);
		write(fd,buffer,strlen(buffer));
	}
	if(body) {
		sprintf(buffer,"%s<P>\n",body);
		write(fd,buffer,strlen(buffer));
	}
	sprintf(buffer,"</BODY>\n");
	write(fd,buffer,strlen(buffer));
}

/**************************************************************************************************/
/* void check501Error( int sessionFD, char *errorString) */ 
/**************************************************************************************************/
void check501Error( int sessionFD, char *errorString)
{
   /*----------- Check if HTTP 1.1  then say it is invalid--------ERROR 501-------------*/
      if (strstr(errorString,"HTTP/1.1") > 0)  {
		if(display) {printf("HTTP 1.1 Version- not supported! \n");}

                proxyMSG(sessionFD,"Error 501","This HTTP version is not supported by the proxy server!","");
		close(sessionFD);
		return;
	        } 

}

/**************************************************************************************************/
/* void proxyHOSTING(int fd) */ 
/**************************************************************************************************/
void proxyHOSTING(int fd)
{
  /* serve requests on fd */
	char buf2[512];
	struct sockaddr_in sin;
	int rfd; /* request destination */
	int n;
	fd_set rfds;
	struct hostent *hostServerName;
	char *wwwHOST;
	char host[128];
	char *h,*rest;
	int portnum;
	struct timeval tv;	
	extern int h_errno;
	char cmd[16];
	int i;

	if(display) printf("* Spawning **************************\n");
	
	n=read(fd,buffer,sizeof(buffer));
	if(n<1) {
		if(lfp) fprintf(lfp,"*** read() failed in child process.***\n");
		if(display) {
			if(n<0) perror("read");
			printf("Nothing read.\n");
		}
		return;
	}

   /* synchronous I/O multiplexing */ 
	FD_ZERO(&rfds);
	FD_SET(fd,&rfds);

	for(i=0;i<15;i++)
		if(buffer[i] && (buffer[i]!=' ')) {
			cmd[i]=(char)toupper((int)buffer[i]);
		} else break;
	cmd[i]='\0';
	
   /*------- Parse the status line if METHOD is no allowed!-------------ERROR 405-------- */
	if(strcmp(cmd,"GET")&&strcmp(cmd,"POST"))  {
		if(display) printf("Not a GET or POST command\n");
		if(lfp) { fprintf(lfp,"Bad command [%s] received.\n---------\n",cmd);
		fprintf(lfp,"%s\n----------\n",buffer);fflush(lfp); }
		proxyMSG(fd,"Error 405",cmd,"This command is not supported by the proxy server.");
		close(fd);
		return;
	        }	

   /* GET http://www.url/content.xxx         */
   /* identify Web-URL , the host site where we are going,then let'parse it   */
	
	for(wwwHOST=buffer;*wwwHOST && (*wwwHOST!='/');wwwHOST++);
	wwwHOST+=2;
	h=host;
	(*info)=host;
	for(;*wwwHOST&&(*wwwHOST!=':')&&(*wwwHOST!='/');wwwHOST++) *(h++)=*wwwHOST;
	*h='\0';
	
	if(*wwwHOST==':') {
		portnum = atoi(wwwHOST+1);
		for(;*wwwHOST!='/';wwwHOST++);
	} else {
		portnum = httpport;
	}
	
	for(rest=wwwHOST;*rest && (*rest!='\n');rest++);
	
	if(*rest)
	{ *rest='\0'; rest++; 
	}
         
     /*----------- Check if HTTP 1.1  then say it is invalid--------ERROR 501-------------*/
       check501Error(fd,wwwHOST);
     
     /*----------- Check if HTTP 1.1  then say it is invalid--------ERROR 501-------------*/

	if(display) {printf("%s http://%s:%d%s\n",cmd,host,portnum,wwwHOST);}
	if(lfp) { 
		fprintf(lfp,"%s http://%s:%d%s\n",cmd,host,portnum,wwwHOST);
		fflush(lfp); 
		}

	/* connect to server */
	if ((rfd = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		if(display) perror("socket");
		if(lfp) fprintf(lfp,"*** socket() failed in child process. ***\n");
		return 0;
	}


	if(display>2) printf("rfd is on fd %d\n",rfd);
	
	if(display) {
		printf("gethostbyname(%s)=",host);
	}
      /*get the hostname of the request web-server */
	hostServerName = gethostbyname(host);
	if(display) {
		if(!hostServerName) {
			printf("null\n");
		}else{
      /* Get the host IP address,and display it in a 4-decimal format */
			printf("%d.%d.%d.%d\n",
				(unsigned char)hostServerName->h_addr[0],
				(unsigned char)hostServerName->h_addr[1],
				(unsigned char)hostServerName->h_addr[2],
				(unsigned char)hostServerName->h_addr[3]
			);
		}
	}
	
       if(!hostServerName) {
		if(display) printf("Host %s not found\n",host);
		if(lfp){ fprintf(lfp,"Host %s was not found.\n",host);
			fflush(lfp); }

      /* Give the equivalent HTTP host status error   */              
                  statusHTTPServer(h_errno,&buf2);
		  proxyMSG(fd,"Sorry!",host,buf2);
		  close(fd);
		 if(lfp) {fprintf(lfp,"** Host %s not found.\n",host);
			fflush(lfp); }
		return 0;
	}

      /* sniffing another session/s...*/
	if(display) printf("Trying %s on port %d...\n",host,portnum);

	sin.sin_family = AF_INET;
	bcopy(hostServerName->h_addr,&sin.sin_addr,sizeof(struct in_addr)) ;
	sin.sin_port = htons((u_short) portnum) ;
	if(connect(rfd, (struct sockaddr *) &sin, sizeof(struct sockaddr_in)) < 0) {
		if(display) perror("connect");
		if(lfp) { fprintf(lfp,"Connect failed to host %s [%d]\n",host,errno);
			fflush(lfp); }

      /* Give the equivalent HTTP connection error   */ 
                 statusHTTPConnections(errno,&buf2);
		 proxyMSG(fd,"Sorry!",host,buf2);
		 close(fd);
		return 0;
	}
        

	if(display) printf("**Connected to %s on port %d\n",host,portnum);
	if(lfp) {
                 
		fprintf(lfp,"**Connected to %s:%d\n",host,portnum);	
		fflush(lfp);
                
	}

	sprintf(buf2,"%s %s\n",cmd,wwwHOST);
	if(write(rfd,buf2,strlen(buf2))<1) {
		perror("write[a]");
		close(fd);
		close(rfd);
	        /* return 0; */
	}
	if(strlen(rest)>0) 
		if(write(rfd,rest,strlen(rest) )<1){
			perror("write[b]");
			close(fd);
			close(rfd);
		 /* return 0; */
		}

	
        /* (1)Allow a program to monitor multiple file descriptors
              ex: select(FD_SETSIZE, &rfds, NONE, NONE, &tv) < 0
           (2) Waiting until one or more of the file descriptors become "ready" for some class of I/O operation.
           (3) A file descriptor is considered ready if it is possible to perform the corresponding I/O operation.
           (4) Perform non-blocking  
               ex: (n=read(rfd,buffer,sizeof(buffer)))<1) break;*/
	for(;;) {
		tv.tv_sec = 60;
		tv.tv_usec = 0;
		FD_SET(rfd,&rfds);
		FD_SET(fd,&rfds);
		if (select(FD_SETSIZE, &rfds, NONE, NONE, &tv) < 0)  {
			
			if(display) { 
			   perror("select"); 
                           puts("timeout");	
			}
			break;
		}
            
     /*  now send anything back and forth until we forwarded all the HTTP data. */
		if( FD_ISSET( rfd, &rfds ) ) {
     /* data coming in , request to the proxy*/
			if(display) printf("+");
			if((n=read(rfd,buffer,sizeof(buffer)))<1) break;
			if(write(fd,buffer,n)<n) break;
		} else {
     /* data going out -> response to the client */
			if(display) printf("-");
			if((n=read(fd,buffer,sizeof(buffer)))<1) break;
			if(write(rfd,buffer,n)<n) break;
		}
	}

    /*  All requested HTTP data are forwared */
	if(lfp) { fprintf(lfp,"Successful proxying...Transfer complete.\n");   
                  fflush(lfp);
                 if (display) { printf("Successful proxying...Transfer complete.\n");}
                 }
               
         
   /* close client & server  socket at this session */ 
	close(rfd);
	close(fd);
}

/***************************************MAIN PROXY PROGRAM*************************************************/
main(int argc, char *argv[])
{
	int sessionID;
	int children= 0;
	union wait uw;	
	struct timeval tv;
	/*extern int optind; */
	extern char *optarg;
	int c,port;
	char statbuf[32];
	struct servent *serverNAME;
	char *logfile=(char *)0;
	int last;

    /* let's  clear screen now... */
        system("clear");
	info=argv+1;
	port=0;
        printf("----------------------------------------------------------\n");
        printf("\033[22;32m       MIS Proxy Server Demo                   \n \033[0m");
        printf("\033[22;32m      Christopher M Coballes                   \n \033[0m");
        printf("----------------------------------------------------------\n");

	while((c=getopt(argc,argv,"dp:l:"))!=-1) 
		switch(c) {
			case 'd': display++; break;
			case 'p': port=atoi(optarg); break;
			case 'l': logfile = optarg; break;
			default: printf("Usage: %s [-d] [-p port] [-l logfile]\n",argv[0]);
				exit(1);
		}


	if(logfile) {
		lfp=fopen(logfile,"a");
		if(!lfp) perror(logfile);
	}

	if(!port) {
		serverNAME = getservbyname("http-proxy","tcp");
		port=(display?PORTTEST:(serverNAME?(u_short)htons(serverNAME->s_port):800));
                
	}

	if(display && serverNAME) printf("Using proxy port [%-10.10s] %d\n",serverNAME->s_name,port);
	argv[1]=statbuf;

  /* signal(SIGCHLD,wait); */
	signal(SIGHUP,SIG_IGN); 

	serverNAME = getservbyname("http","tcp");
	httpport=(serverNAME?(u_short)htons(serverNAME->s_port):80);
	if(display) printf("Using http port [%-10.10s] %d\n",serverNAME->s_name,httpport);

  /* open port to listen to */
	if ((sessionSocket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		if(display) perror("socket");
        	return 0;
	}
        else {
          if (display)
          { printf("** Listening to the port \n"); }
	}
	sc_in.sin_family = AF_INET;
	sc_in.sin_addr.s_addr = INADDR_ANY;
	sc_in.sin_port = htons((u_short) port);
	if (bind(sessionSocket, (struct sockaddr *) &sc_in, sizeof(sc_in)) < 0) {
		perror("bind: proxy");
		if(lfp) fprintf(lfp,"bind failed.\n");
		return 0;
	}
	if (listen(sessionSocket, 25) < 0) {
		perror("listen");
		return 0;
	}

	/* now try and set the socket option to allow the reuse of address */
	{
		int b;
		b=-1;
		if(setsockopt(sessionSocket,SOL_SOCKET,SO_REUSEADDR,&b,4)) {
			perror("setsockopt");
			if(lfp) fprintf(lfp,"setsockopt failed.\n");
			exit(1);
		}
	}

	/* set up fd mask */
	FD_ZERO(&active);
	FD_SET(sessionSocket,&active);

	/* dont sets id if in the display mode */
	if(!display)  {
		if( fork() ) exit(0); /* multi-session is done through forking */
        /* this function may not exist on all UNIXs. */
		setsid();
	/* Note:	
           (-) if you dont have setsid(), then do the following:
		(1) close all fds, 
                (2)set process group this getpid(), 
                (3)use ioctl to set NOTTY on stdin(not too dangerous). 
                 This latter is not *vital
		(4) after that,everything should still work anyway.*/
	}

	if(lfp) { fprintf(lfp,"*** Program starting!\n"); fflush(lfp); }
	/* SELECT LOOP */
	/* we loop until there are clients requesting for a session (proxying)! */
	children=0;
	last = sessionSocket;
	for( ;; ) {
		sprintf(statbuf,"port %d, %d procs, last=%d" ,port,children,last);
		if(display) printf("** Waiting..\n");
		while(wait3(&uw,WNOHANG,NULL)>0) {
			children--;
			if(display) printf("** Removed zombie\n");
		}
		if(display) printf("** Selecting HTTP session..\n");
		tv.tv_sec = 60;
		tv.tv_usec = 0;
		FD_ZERO(&active);
		FD_SET(sessionSocket,&active);
		if (select(FD_SETSIZE, &active, NONE, NONE, &tv) < 0) {
			if(display)
			perror("select");
			if(lfp) fprintf(lfp,"*** Selecting session failed! ***\n");
			break;
		}
		if( FD_ISSET(sessionSocket,&active) ) {
			if ((sessionID = accept(sessionSocket, IGNORE, (int *) 0)) < 0) {
				if(display) perror("accept");
				if(lfp) { fprintf(lfp,"* accept() failed\n"); fflush(lfp);}
			} else {
				last=sessionID;
				children++;
				if(!fork()) {
					close(sessionSocket);
					proxyHOSTING(sessionID);
					if(display) printf("* Child session exiting!\n");
					exit(0);
				}
				close(sessionID);
			}
		}
	}
	if(display) printf("** Bye.\n");
	if(lfp) fprintf(lfp,"***** Program exiting! *****\n");
	exit(0);
}
